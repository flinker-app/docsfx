#!/usr/bin/env python3
"""
Convert IFC files to That Open .frag files (Fragments schema) using Python.

This converter is implemented in Python with:
- ifcopenshell: IFC geometry extraction
- flatbuffers: Fragments binary serialization

Notes:
- Geometry is exported as shell representations (triangle profiles).
- The output is compressed with zlib by default (compatible with That Open loaders).
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
import uuid
import zlib
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import DefaultDict, Dict, Iterable, List, Optional, Sequence, Tuple

import flatbuffers
import ifcopenshell
import ifcopenshell.geom


SCHEMA_DIR = Path(__file__).resolve().parent / "_schema"
if str(SCHEMA_DIR) not in sys.path:
    sys.path.insert(0, str(SCHEMA_DIR))

# Generated from That Open Fragments schema (index.fbs)
import BigShellHole as FBBigShellHole
import BigShellProfile as FBBigShellProfile
import FloatVector as FBFloatVector
import Material as FBMaterial
import Meshes as FBMeshes
import Model as FBModel
import RenderedFaces as FBRenderedFaces
import Representation as FBRepresentation
import RepresentationClass as FBRepresentationClass
import Sample as FBSample
import Shell as FBShell
import ShellHole as FBShellHole
import ShellProfile as FBShellProfile
import ShellType as FBShellType
import Stroke as FBStroke
import Transform as FBTransform


USHORT_SAFE_LIMIT = 65000
IDENTITY_TRANSFORM = (0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0)
DEFAULT_COLOR = (180, 180, 180, 255)


@dataclass
class ItemRecord:
    local_id: int
    guid: str
    category: str
    transform: Tuple[float, float, float, float, float, float, float, float, float]


@dataclass
class ShellRecord:
    points: List[Tuple[float, float, float]]
    profiles: List[List[int]]
    holes: List[Tuple[int, List[int]]]
    big_profiles: List[List[int]]
    big_holes: List[Tuple[int, List[int]]]
    shell_type: int
    profiles_face_ids: List[int]
    bbox: Tuple[float, float, float, float, float, float]


@dataclass
class RepresentationRecord:
    shell_index: int
    bbox: Tuple[float, float, float, float, float, float]


@dataclass
class SampleRecord:
    item_index: int
    material_index: int
    representation_index: int
    local_transform_index: int


@dataclass
class ConversionStats:
    source_file: Path
    output_file: Path
    items: int
    representations: int
    materials: int
    samples: int
    shells: int
    raw_size: int
    output_size: int
    compressed: bool
    elapsed_s: float


def _auto_threads() -> int:
    # ifcopenshell iterator benefits from parallel tessellation, but very high values
    # can hurt due to memory pressure.
    cpu = os.cpu_count() or 1
    return max(1, min(4, cpu))


def _safe_float(value: object, default: float = 0.0) -> float:
    try:
        result = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default
    if not math.isfinite(result):
        return default
    if abs(result) < 1e-12:
        return 0.0
    return result


def _clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def _to_color_byte(value: float, default_normalized: float = 0.7) -> int:
    if not math.isfinite(value):
        value = default_normalized
    # if normalized [0,1], scale; otherwise assume [0,255]
    if value <= 1.0:
        value *= 255.0
    return int(round(_clamp(value, 0.0, 255.0)))


def _style_component(color_obj: object, component_name: str, default: float) -> float:
    if color_obj is None:
        return default
    candidate = getattr(color_obj, component_name, None)
    if callable(candidate):
        try:
            return _safe_float(candidate(), default)
        except Exception:
            return default
    return _safe_float(candidate, default)


def _extract_rgba(style: object) -> Tuple[int, int, int, int]:
    if style is None:
        return DEFAULT_COLOR

    color_obj = None
    get_color = getattr(style, "get_color", None)
    if callable(get_color):
        try:
            color_obj = get_color()
        except Exception:
            color_obj = None

    if color_obj is None:
        diffuse = getattr(style, "diffuse", None)
        if callable(diffuse):
            try:
                color_obj = diffuse()
            except Exception:
                color_obj = None

    if color_obj is None:
        surface = getattr(style, "surface", None)
        if callable(surface):
            try:
                color_obj = surface()
            except Exception:
                color_obj = None
        else:
            color_obj = surface

    r = _to_color_byte(_style_component(color_obj, "r", 0.7), 0.7)
    g = _to_color_byte(_style_component(color_obj, "g", 0.7), 0.7)
    b = _to_color_byte(_style_component(color_obj, "b", 0.7), 0.7)

    transparency = getattr(style, "transparency", 0.0)
    if callable(transparency):
        try:
            transparency = transparency()
        except Exception:
            transparency = 0.0
    transparency = _clamp(_safe_float(transparency, 0.0), 0.0, 1.0)
    alpha = _to_color_byte(1.0 - transparency, 1.0)
    return (r, g, b, alpha)


def _ifc_to_thatopen_xyz(x: float, y: float, z: float) -> Tuple[float, float, float]:
    # IFC is typically Z-up; That Open/Three stack is Y-up.
    # Mapping from That Open ifc-utils:
    # y = z
    # z = -y
    return (x, z, -y)


def _matrix_to_transform(
    matrix: object,
    *,
    axis_conversion: bool,
) -> Tuple[float, float, float, float, float, float, float, float, float]:
    if not isinstance(matrix, (tuple, list)) or len(matrix) != 16:
        return IDENTITY_TRANSFORM
    m = matrix
    px = _safe_float(m[12], 0.0)
    py = _safe_float(m[13], 0.0)
    pz = _safe_float(m[14], 0.0)
    dxx = _safe_float(m[0], 1.0)
    dxy = _safe_float(m[1], 0.0)
    dxz = _safe_float(m[2], 0.0)
    dyx = _safe_float(m[4], 0.0)
    dyy = _safe_float(m[5], 1.0)
    dyz = _safe_float(m[6], 0.0)
    if axis_conversion:
        px, py, pz = _ifc_to_thatopen_xyz(px, py, pz)
        dxx, dxy, dxz = _ifc_to_thatopen_xyz(dxx, dxy, dxz)
        dyx, dyy, dyz = _ifc_to_thatopen_xyz(dyx, dyy, dyz)
    return (px, py, pz, dxx, dxy, dxz, dyx, dyy, dyz)


def _create_uoffset_vector(
    builder: flatbuffers.Builder,
    start_vector_fn,
    offsets: Sequence[int],
) -> int:
    start_vector_fn(builder, len(offsets))
    for offset in reversed(offsets):
        builder.PrependUOffsetTRelative(offset)
    return builder.EndVector()


def _create_uint32_vector(
    builder: flatbuffers.Builder,
    start_vector_fn,
    values: Sequence[int],
) -> int:
    start_vector_fn(builder, len(values))
    for value in reversed(values):
        builder.PrependUint32(int(value))
    return builder.EndVector()


def _create_uint16_vector(
    builder: flatbuffers.Builder,
    start_vector_fn,
    values: Sequence[int],
) -> int:
    start_vector_fn(builder, len(values))
    for value in reversed(values):
        builder.PrependUint16(int(value))
    return builder.EndVector()


def _create_int32_vector(
    builder: flatbuffers.Builder,
    start_vector_fn,
    values: Sequence[int],
) -> int:
    start_vector_fn(builder, len(values))
    for value in reversed(values):
        builder.PrependInt32(int(value))
    return builder.EndVector()


def _create_string_vector(
    builder: flatbuffers.Builder,
    start_vector_fn,
    values: Sequence[str],
) -> int:
    offsets = [builder.CreateString(value) for value in values]
    return _create_uoffset_vector(builder, start_vector_fn, offsets)


def _build_shell_from_triangles(
    verts: Sequence[float],
    faces: Sequence[int],
    triangle_indices: Sequence[int],
) -> Optional[ShellRecord]:
    points_lookup: Dict[Tuple[float, float, float], int] = {}
    vertex_to_point: Dict[int, int] = {}
    points: List[Tuple[float, float, float]] = []
    profiles: List[List[int]] = []

    min_x = math.inf
    min_y = math.inf
    min_z = math.inf
    max_x = -math.inf
    max_y = -math.inf
    max_z = -math.inf

    verts_len = len(verts)

    def point_index(vertex_index: int) -> Optional[int]:
        nonlocal min_x, min_y, min_z, max_x, max_y, max_z
        existing = vertex_to_point.get(vertex_index)
        if existing is not None:
            return existing

        base = vertex_index * 3
        if base + 2 >= verts_len:
            return None
        x = float(verts[base])
        y = float(verts[base + 1])
        z = float(verts[base + 2])
        key = (x, y, z)
        if key in points_lookup:
            found = points_lookup[key]
            vertex_to_point[vertex_index] = found
            return found
        index = len(points)
        points_lookup[key] = index
        vertex_to_point[vertex_index] = index
        points.append(key)
        min_x = min(min_x, x)
        min_y = min(min_y, y)
        min_z = min(min_z, z)
        max_x = max(max_x, x)
        max_y = max(max_y, y)
        max_z = max(max_z, z)
        return index

    for tri_idx in triangle_indices:
        tri_base = tri_idx * 3
        if tri_base + 2 >= len(faces):
            continue
        v0 = faces[tri_base]
        v1 = faces[tri_base + 1]
        v2 = faces[tri_base + 2]
        i0 = point_index(v0)
        i1 = point_index(v1)
        i2 = point_index(v2)
        if i0 is None or i1 is None or i2 is None:
            continue
        if i0 == i1 or i1 == i2 or i2 == i0:
            continue
        profiles.append([i0, i1, i2])

    if not profiles or len(points) < 3:
        return None

    bbox = (min_x, min_y, min_z, max_x, max_y, max_z)
    profile_face_ids = [0] * len(profiles)
    is_big = len(points) > USHORT_SAFE_LIMIT

    if is_big:
        return ShellRecord(
            points=points,
            profiles=[],
            holes=[],
            big_profiles=profiles,
            big_holes=[],
            shell_type=FBShellType.ShellType.BIG,
            profiles_face_ids=profile_face_ids,
            bbox=bbox,
        )

    return ShellRecord(
        points=points,
        profiles=profiles,
        holes=[],
        big_profiles=[],
        big_holes=[],
        shell_type=FBShellType.ShellType.NONE,
        profiles_face_ids=profile_face_ids,
        bbox=bbox,
    )


def _build_shell_table(builder: flatbuffers.Builder, shell: ShellRecord) -> int:
    FBShell.ShellStartPointsVector(builder, len(shell.points))
    for x, y, z in reversed(shell.points):
        FBFloatVector.CreateFloatVector(builder, x, y, z)
    points_offset = builder.EndVector()

    profile_offsets: List[int] = []
    for indices in shell.profiles:
        indices_offset = _create_uint16_vector(
            builder,
            FBShellProfile.ShellProfileStartIndicesVector,
            indices,
        )
        FBShellProfile.ShellProfileStart(builder)
        FBShellProfile.ShellProfileAddIndices(builder, indices_offset)
        profile_offsets.append(FBShellProfile.ShellProfileEnd(builder))
    profiles_offset = _create_uoffset_vector(
        builder,
        FBShell.ShellStartProfilesVector,
        profile_offsets,
    )

    holes_offsets: List[int] = []
    for profile_id, hole_indices in shell.holes:
        hole_indices_offset = _create_uint16_vector(
            builder,
            FBShellHole.ShellHoleStartIndicesVector,
            hole_indices,
        )
        FBShellHole.ShellHoleStart(builder)
        FBShellHole.ShellHoleAddIndices(builder, hole_indices_offset)
        FBShellHole.ShellHoleAddProfileId(builder, profile_id)
        holes_offsets.append(FBShellHole.ShellHoleEnd(builder))
    holes_offset = _create_uoffset_vector(
        builder,
        FBShell.ShellStartHolesVector,
        holes_offsets,
    )

    big_profile_offsets: List[int] = []
    for indices in shell.big_profiles:
        indices_offset = _create_uint32_vector(
            builder,
            FBBigShellProfile.BigShellProfileStartIndicesVector,
            indices,
        )
        FBBigShellProfile.BigShellProfileStart(builder)
        FBBigShellProfile.BigShellProfileAddIndices(builder, indices_offset)
        big_profile_offsets.append(FBBigShellProfile.BigShellProfileEnd(builder))
    big_profiles_offset = _create_uoffset_vector(
        builder,
        FBShell.ShellStartBigProfilesVector,
        big_profile_offsets,
    )

    big_hole_offsets: List[int] = []
    for profile_id, hole_indices in shell.big_holes:
        hole_indices_offset = _create_uint32_vector(
            builder,
            FBBigShellHole.BigShellHoleStartIndicesVector,
            hole_indices,
        )
        FBBigShellHole.BigShellHoleStart(builder)
        FBBigShellHole.BigShellHoleAddIndices(builder, hole_indices_offset)
        FBBigShellHole.BigShellHoleAddProfileId(builder, profile_id)
        big_hole_offsets.append(FBBigShellHole.BigShellHoleEnd(builder))
    big_holes_offset = _create_uoffset_vector(
        builder,
        FBShell.ShellStartBigHolesVector,
        big_hole_offsets,
    )

    face_ids_offset = _create_uint16_vector(
        builder,
        FBShell.ShellStartProfilesFaceIdsVector,
        shell.profiles_face_ids,
    )

    FBShell.ShellStart(builder)
    FBShell.ShellAddProfiles(builder, profiles_offset)
    FBShell.ShellAddHoles(builder, holes_offset)
    FBShell.ShellAddPoints(builder, points_offset)
    FBShell.ShellAddBigProfiles(builder, big_profiles_offset)
    FBShell.ShellAddBigHoles(builder, big_holes_offset)
    FBShell.ShellAddType(builder, shell.shell_type)
    FBShell.ShellAddProfilesFaceIds(builder, face_ids_offset)
    return FBShell.ShellEnd(builder)


def _build_frag_bytes(
    source_ifc: Path,
    source_schema: str,
    items: List[ItemRecord],
    shells: List[ShellRecord],
    representations: List[RepresentationRecord],
    materials: List[Tuple[int, int, int, int]],
    samples: List[SampleRecord],
) -> bytes:
    builder = flatbuffers.Builder(1024)

    shell_offsets = [_build_shell_table(builder, shell) for shell in shells]
    shells_offset = _create_uoffset_vector(
        builder,
        FBMeshes.MeshesStartShellsVector,
        shell_offsets,
    )

    FBMeshes.MeshesStartCircleExtrusionsVector(builder, 0)
    circle_extrusions_offset = builder.EndVector()

    FBMeshes.MeshesStartRepresentationsVector(builder, len(representations))
    for representation in reversed(representations):
        min_x, min_y, min_z, max_x, max_y, max_z = representation.bbox
        FBRepresentation.CreateRepresentation(
            builder,
            representation.shell_index,
            min_x,
            min_y,
            min_z,
            max_x,
            max_y,
            max_z,
            FBRepresentationClass.RepresentationClass.SHELL,
        )
    representations_offset = builder.EndVector()

    FBMeshes.MeshesStartMaterialsVector(builder, len(materials))
    for r, g, b, a in reversed(materials):
        FBMaterial.CreateMaterial(
            builder,
            r,
            g,
            b,
            a,
            FBRenderedFaces.RenderedFaces.ONE,
            FBStroke.Stroke.DEFAULT,
        )
    materials_offset = builder.EndVector()

    FBMeshes.MeshesStartSamplesVector(builder, len(samples))
    for sample in reversed(samples):
        FBSample.CreateSample(
            builder,
            sample.item_index,
            sample.material_index,
            sample.representation_index,
            sample.local_transform_index,
        )
    samples_offset = builder.EndVector()

    # Local transforms: only identity transform (index 0)
    FBMeshes.MeshesStartLocalTransformsVector(builder, 1)
    FBTransform.CreateTransform(builder, *IDENTITY_TRANSFORM)
    local_transforms_offset = builder.EndVector()

    FBMeshes.MeshesStartGlobalTransformsVector(builder, len(items))
    for item in reversed(items):
        FBTransform.CreateTransform(builder, *item.transform)
    global_transforms_offset = builder.EndVector()

    # IDs used by Fragments edit/query APIs
    max_item_local_id = max((item.local_id for item in items), default=0)
    next_local_id = max_item_local_id + 1

    global_transform_ids = list(range(next_local_id, next_local_id + len(items)))
    next_local_id += len(items)

    local_transform_ids = [next_local_id]
    next_local_id += 1

    representation_ids = list(range(next_local_id, next_local_id + len(representations)))
    next_local_id += len(representations)

    material_ids = list(range(next_local_id, next_local_id + len(materials)))
    next_local_id += len(materials)

    sample_ids = list(range(next_local_id, next_local_id + len(samples)))
    next_local_id += len(samples)

    max_local_id = next_local_id

    meshes_items = list(range(len(items)))

    meshes_items_offset = _create_uint32_vector(
        builder,
        FBMeshes.MeshesStartMeshesItemsVector,
        meshes_items,
    )
    representation_ids_offset = _create_uint32_vector(
        builder,
        FBMeshes.MeshesStartRepresentationIdsVector,
        representation_ids,
    )
    sample_ids_offset = _create_uint32_vector(
        builder,
        FBMeshes.MeshesStartSampleIdsVector,
        sample_ids,
    )
    material_ids_offset = _create_uint32_vector(
        builder,
        FBMeshes.MeshesStartMaterialIdsVector,
        material_ids,
    )
    local_transform_ids_offset = _create_uint32_vector(
        builder,
        FBMeshes.MeshesStartLocalTransformIdsVector,
        local_transform_ids,
    )
    global_transform_ids_offset = _create_uint32_vector(
        builder,
        FBMeshes.MeshesStartGlobalTransformIdsVector,
        global_transform_ids,
    )

    coordinates_offset = FBTransform.CreateTransform(builder, *IDENTITY_TRANSFORM)

    FBMeshes.MeshesStart(builder)
    FBMeshes.MeshesAddCoordinates(builder, coordinates_offset)
    FBMeshes.MeshesAddMeshesItems(builder, meshes_items_offset)
    FBMeshes.MeshesAddSamples(builder, samples_offset)
    FBMeshes.MeshesAddRepresentations(builder, representations_offset)
    FBMeshes.MeshesAddMaterials(builder, materials_offset)
    FBMeshes.MeshesAddCircleExtrusions(builder, circle_extrusions_offset)
    FBMeshes.MeshesAddShells(builder, shells_offset)
    FBMeshes.MeshesAddLocalTransforms(builder, local_transforms_offset)
    FBMeshes.MeshesAddGlobalTransforms(builder, global_transforms_offset)
    FBMeshes.MeshesAddMaterialIds(builder, material_ids_offset)
    FBMeshes.MeshesAddRepresentationIds(builder, representation_ids_offset)
    FBMeshes.MeshesAddSampleIds(builder, sample_ids_offset)
    FBMeshes.MeshesAddLocalTransformIds(builder, local_transform_ids_offset)
    FBMeshes.MeshesAddGlobalTransformIds(builder, global_transform_ids_offset)
    meshes_offset = FBMeshes.MeshesEnd(builder)

    item_local_ids = [item.local_id for item in items]
    categories = [item.category for item in items]

    guids: List[str] = []
    guids_items: List[int] = []
    for item in items:
        if item.guid:
            guids.append(item.guid)
            guids_items.append(item.local_id)

    local_ids_offset = _create_uint32_vector(
        builder,
        FBModel.ModelStartLocalIdsVector,
        item_local_ids,
    )
    categories_offset = _create_string_vector(
        builder,
        FBModel.ModelStartCategoriesVector,
        categories,
    )
    guids_offset = _create_string_vector(
        builder,
        FBModel.ModelStartGuidsVector,
        guids,
    )
    guids_items_offset = _create_uint32_vector(
        builder,
        FBModel.ModelStartGuidsItemsVector,
        guids_items,
    )

    attributes_offset = _create_uoffset_vector(
        builder,
        FBModel.ModelStartAttributesVector,
        [],
    )
    relations_offset = _create_uoffset_vector(
        builder,
        FBModel.ModelStartRelationsVector,
        [],
    )
    relations_items_offset = _create_int32_vector(
        builder,
        FBModel.ModelStartRelationsItemsVector,
        [],
    )
    unique_attributes_offset = _create_string_vector(
        builder,
        FBModel.ModelStartUniqueAttributesVector,
        [],
    )
    relation_names_offset = _create_string_vector(
        builder,
        FBModel.ModelStartRelationNamesVector,
        [],
    )

    metadata = {
        "schema": source_schema,
        "source": source_ifc.name,
        "converter": "ifc-to-frag-python",
        "version": 1,
    }
    metadata_offset = builder.CreateString(json.dumps(metadata, separators=(",", ":")))
    model_guid_offset = builder.CreateString(str(uuid.uuid4()))

    FBModel.ModelStart(builder)
    FBModel.ModelAddMetadata(builder, metadata_offset)
    FBModel.ModelAddGuids(builder, guids_offset)
    FBModel.ModelAddGuidsItems(builder, guids_items_offset)
    FBModel.ModelAddMaxLocalId(builder, max_local_id)
    FBModel.ModelAddLocalIds(builder, local_ids_offset)
    FBModel.ModelAddCategories(builder, categories_offset)
    FBModel.ModelAddMeshes(builder, meshes_offset)
    FBModel.ModelAddAttributes(builder, attributes_offset)
    FBModel.ModelAddRelations(builder, relations_offset)
    FBModel.ModelAddRelationsItems(builder, relations_items_offset)
    FBModel.ModelAddGuid(builder, model_guid_offset)
    FBModel.ModelAddUniqueAttributes(builder, unique_attributes_offset)
    FBModel.ModelAddRelationNames(builder, relation_names_offset)
    model_offset = FBModel.ModelEnd(builder)

    builder.Finish(model_offset, file_identifier=b"0001")
    return bytes(builder.Output())


def convert_ifc_to_frag(
    ifc_path: Path,
    output_path: Path,
    *,
    raw: bool = False,
    threads: int = 1,
    compression_level: int = 3,
    axis_conversion: bool = True,
    quiet: bool = False,
) -> ConversionStats:
    start_time = time.perf_counter()

    model = ifcopenshell.open(str(ifc_path))
    source_schema = str(getattr(model, "schema", "UNKNOWN"))

    settings = ifcopenshell.geom.settings()
    if hasattr(settings, "USE_WORLD_COORDS"):
        settings.set(settings.USE_WORLD_COORDS, False)
    if hasattr(settings, "APPLY_DEFAULT_MATERIALS"):
        settings.set(settings.APPLY_DEFAULT_MATERIALS, True)
    if hasattr(settings, "WELD_VERTICES"):
        settings.set(settings.WELD_VERTICES, False)

    iterator = ifcopenshell.geom.iterator(settings, model, max(1, threads))
    initialized = iterator.initialize()
    if not initialized:
        raise RuntimeError(f"Failed to initialize IFC geometry iterator for {ifc_path}")

    items: List[ItemRecord] = []
    shells: List[ShellRecord] = []
    representations: List[RepresentationRecord] = []
    materials: List[Tuple[int, int, int, int]] = []
    samples: List[SampleRecord] = []

    item_index_by_local_id: Dict[int, int] = {}
    representation_index_by_key: Dict[Tuple[object, int], int] = {}
    material_index_by_rgba: Dict[Tuple[int, int, int, int], int] = {}

    shape_count = 0
    while True:
        shape = iterator.get()
        shape_count += 1

        local_id = int(getattr(shape, "id", 0))
        if local_id <= 0:
            if not iterator.next():
                break
            continue

        if local_id not in item_index_by_local_id:
            matrix = getattr(getattr(shape, "transformation", None), "matrix", None)
            transform = _matrix_to_transform(matrix, axis_conversion=axis_conversion)
            category = str(getattr(shape, "type", "Unknown") or "Unknown")
            guid = str(getattr(shape, "guid", "") or "")
            item_index_by_local_id[local_id] = len(items)
            items.append(
                ItemRecord(
                    local_id=local_id,
                    guid=guid,
                    category=category,
                    transform=transform,
                )
            )

        item_index = item_index_by_local_id[local_id]
        geom = getattr(shape, "geometry", None)
        if geom is None:
            if not iterator.next():
                break
            continue

        # Copy to Python tuples once; random access on the native wrappers is slower.
        verts = tuple(getattr(geom, "verts", ()))
        faces = tuple(getattr(geom, "faces", ()))
        triangle_count = len(faces) // 3
        if triangle_count == 0 or len(verts) < 9:
            if not iterator.next():
                break
            continue

        raw_material_ids = getattr(geom, "material_ids", None)
        if raw_material_ids is None:
            material_ids_per_triangle: Sequence[int] = (0,) * triangle_count
        else:
            material_ids_per_triangle = tuple(int(v) for v in raw_material_ids)
            if len(material_ids_per_triangle) != triangle_count:
                material_ids_per_triangle = (0,) * triangle_count

        triangles_by_material: DefaultDict[int, List[int]]
        triangles_by_material = defaultdict(list)
        setdefault_triangles = triangles_by_material.setdefault
        for tri_idx, material_id_raw in enumerate(material_ids_per_triangle):
            material_id = int(material_id_raw)
            bucket = setdefault_triangles(material_id, [])
            bucket.append(tri_idx)

        geometry_id_raw = getattr(geom, "id", shape_count)
        try:
            geometry_id: object = int(geometry_id_raw)
        except Exception:
            geometry_id = str(geometry_id_raw)
        shape_materials = tuple(getattr(geom, "materials", ()) or ())

        for material_id, tri_indices in triangles_by_material.items():
            repr_key = (geometry_id, int(material_id))
            representation_index = representation_index_by_key.get(repr_key)
            if representation_index is None:
                shell = _build_shell_from_triangles(verts, faces, tri_indices)
                if shell is None:
                    continue
                shell_index = len(shells)
                shells.append(shell)
                representation_index = len(representations)
                representations.append(
                    RepresentationRecord(
                        shell_index=shell_index,
                        bbox=shell.bbox,
                    )
                )
                representation_index_by_key[repr_key] = representation_index

            style = None
            if 0 <= material_id < len(shape_materials):
                style = shape_materials[material_id]
            rgba = _extract_rgba(style)
            material_index = material_index_by_rgba.get(rgba)
            if material_index is None:
                material_index = len(materials)
                materials.append(rgba)
                material_index_by_rgba[rgba] = material_index

            samples.append(
                SampleRecord(
                    item_index=item_index,
                    material_index=material_index,
                    representation_index=representation_index,
                    local_transform_index=0,
                )
            )

        if not quiet and shape_count % 500 == 0:
            print(
                f"[{ifc_path.name}] processed {shape_count} shapes | "
                f"items={len(items)} reps={len(representations)} samples={len(samples)}"
            )

        if not iterator.next():
            break

    raw_bytes = _build_frag_bytes(
        source_ifc=ifc_path,
        source_schema=source_schema,
        items=items,
        shells=shells,
        representations=representations,
        materials=materials,
        samples=samples,
    )

    if raw:
        output_bytes = raw_bytes
    else:
        output_bytes = zlib.compress(raw_bytes, level=compression_level)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(output_bytes)

    elapsed_s = time.perf_counter() - start_time
    return ConversionStats(
        source_file=ifc_path,
        output_file=output_path,
        items=len(items),
        representations=len(representations),
        materials=len(materials),
        samples=len(samples),
        shells=len(shells),
        raw_size=len(raw_bytes),
        output_size=len(output_bytes),
        compressed=not raw,
        elapsed_s=elapsed_s,
    )


def _collect_ifc_files(inputs: Iterable[str]) -> List[Path]:
    files: List[Path] = []
    for input_str in inputs:
        candidate = Path(input_str).expanduser().resolve()
        if candidate.is_file() and candidate.suffix.lower() == ".ifc":
            files.append(candidate)
            continue
        if candidate.is_dir():
            files.extend(sorted(candidate.glob("*.ifc")))
            continue
        raise FileNotFoundError(f"Input path does not exist or is not an IFC: {candidate}")
    unique = sorted(set(files))
    return unique


def _build_output_path(ifc_path: Path, output_dir: Optional[Path]) -> Path:
    if output_dir is None:
        return ifc_path.with_suffix(".frag")
    return output_dir / f"{ifc_path.stem}.frag"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Convert IFC files to That Open .frag files using Python (ifcopenshell + flatbuffers)."
    )
    parser.add_argument(
        "inputs",
        nargs="+",
        help="IFC files and/or directories containing IFC files.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Output directory for .frag files. Defaults to each IFC file directory.",
    )
    parser.add_argument(
        "--raw",
        action="store_true",
        help="Write raw (uncompressed) .frag bytes. Default is zlib-compressed.",
    )
    parser.add_argument(
        "--threads",
        type=int,
        default=0,
        help="Geometry iterator threads for ifcopenshell (default: auto).",
    )
    parser.add_argument(
        "--compression-level",
        type=int,
        default=3,
        help="zlib compression level 0..9 (default: 3, faster than zlib default).",
    )
    parser.add_argument(
        "--no-axis-conversion",
        action="store_true",
        help="Disable IFC Z-up to Y-up axis conversion.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing .frag files.",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress progress output.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        ifc_files = _collect_ifc_files(args.inputs)
    except Exception as exc:
        print(f"Input error: {exc}", file=sys.stderr)
        return 2

    if not ifc_files:
        print("No IFC files found.", file=sys.stderr)
        return 2

    output_dir: Optional[Path] = None
    if args.output_dir is not None:
        output_dir = args.output_dir.expanduser().resolve()
        output_dir.mkdir(parents=True, exist_ok=True)

    failures = 0
    threads = args.threads if args.threads > 0 else _auto_threads()
    compression_level = int(_clamp(float(args.compression_level), 0, 9))
    axis_conversion = not args.no_axis_conversion

    for ifc_path in ifc_files:
        output_path = _build_output_path(ifc_path, output_dir)
        if output_path.exists() and not args.overwrite:
            print(f"Skipping existing file: {output_path}")
            continue
        try:
            stats = convert_ifc_to_frag(
                ifc_path,
                output_path,
                raw=args.raw,
                threads=threads,
                compression_level=compression_level,
                axis_conversion=axis_conversion,
                quiet=args.quiet,
            )
            print(
                f"Converted {stats.source_file.name} -> {stats.output_file.name} | "
                f"items={stats.items} reps={stats.representations} samples={stats.samples} "
                f"materials={stats.materials} shells={stats.shells} "
                f"size={stats.output_size / (1024 * 1024):.2f} MiB "
                f"({stats.elapsed_s:.1f}s, {'raw' if not stats.compressed else 'compressed'})"
            )
        except Exception as exc:
            failures += 1
            print(f"FAILED: {ifc_path} -> {exc}", file=sys.stderr)

    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
