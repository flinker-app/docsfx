#!/usr/bin/env python3
"""
Validate That Open .frag files produced by ifc_to_frag.py.

This validator:
- opens raw or zlib-compressed .frag
- parses FlatBuffers model
- runs integrity checks over samples/representations/shells
- prints a concise summary
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import zlib
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

SCHEMA_DIR = Path(__file__).resolve().parent / "_schema"
if str(SCHEMA_DIR) not in sys.path:
    sys.path.insert(0, str(SCHEMA_DIR))

import Model as FBModel
import BoundingBox as FBBoundingBox
import FloatVector as FBFloatVector
import RepresentationClass as FBRepresentationClass
import ShellType as FBShellType


@dataclass
class FragSummary:
    file: str
    compressed_input: bool
    local_ids: int
    categories: int
    guids: int
    meshes_items: int
    global_transforms: int
    local_transforms: int
    materials: int
    representations: int
    shells: int
    circle_extrusions: int
    samples: int
    max_local_id: int


def _has_identifier(data: bytes) -> bool:
    try:
        return bool(FBModel.Model.ModelBufferHasIdentifier(data, 0))
    except Exception:
        return False


def _inflate_if_needed(data: bytes) -> Tuple[bytes, bool]:
    if _has_identifier(data):
        return data, False

    inflate_errors: List[str] = []
    for args in ((), (-zlib.MAX_WBITS,)):
        try:
            inflated = zlib.decompress(data, *args)
        except Exception as exc:
            inflate_errors.append(str(exc))
            continue
        if _has_identifier(inflated):
            return inflated, True

    message = "; ".join(inflate_errors) if inflate_errors else "unknown zlib error"
    raise ValueError(f"Input is not a valid raw/compressed .frag (identifier 0001 not found). Details: {message}")


def _is_finite_bbox(min_x: float, min_y: float, min_z: float, max_x: float, max_y: float, max_z: float) -> bool:
    return all(
        math.isfinite(v)
        for v in (min_x, min_y, min_z, max_x, max_y, max_z)
    )


def validate_frag(path: Path) -> FragSummary:
    raw_input = path.read_bytes()
    model_bytes, compressed_input = _inflate_if_needed(raw_input)

    model = FBModel.Model.GetRootAs(model_bytes, 0)
    meshes = model.Meshes()
    if meshes is None:
        raise ValueError("Model.meshes is missing")

    local_ids_len = model.LocalIdsLength()
    categories_len = model.CategoriesLength()
    guids_len = model.GuidsLength()

    meshes_items_len = meshes.MeshesItemsLength()
    global_transforms_len = meshes.GlobalTransformsLength()
    local_transforms_len = meshes.LocalTransformsLength()
    materials_len = meshes.MaterialsLength()
    representations_len = meshes.RepresentationsLength()
    shells_len = meshes.ShellsLength()
    circle_extrusions_len = meshes.CircleExtrusionsLength()
    samples_len = meshes.SamplesLength()

    if categories_len != local_ids_len:
        raise ValueError(
            f"categories/local_ids length mismatch: {categories_len} != {local_ids_len}"
        )

    if meshes_items_len != global_transforms_len:
        raise ValueError(
            "meshes_items/global_transforms length mismatch: "
            f"{meshes_items_len} != {global_transforms_len}"
        )

    if local_transforms_len == 0:
        raise ValueError("No local transforms found (expected at least identity transform)")

    for i in range(representations_len):
        representation = meshes.Representations(i)
        if representation is None:
            raise ValueError(f"Null representation at index {i}")
        bbox = representation.Bbox(FBBoundingBox.BoundingBox())
        if bbox is None:
            raise ValueError(f"Missing bbox in representation {i}")
        bb_min = bbox.Min(FBFloatVector.FloatVector())
        bb_max = bbox.Max(FBFloatVector.FloatVector())
        if bb_min is None or bb_max is None:
            raise ValueError(f"Malformed bbox in representation {i}")
        if not _is_finite_bbox(
            bb_min.X(),
            bb_min.Y(),
            bb_min.Z(),
            bb_max.X(),
            bb_max.Y(),
            bb_max.Z(),
        ):
            raise ValueError(f"Non-finite bbox values in representation {i}")

        repr_class = representation.RepresentationClass()
        repr_id = representation.Id()
        if repr_class == FBRepresentationClass.RepresentationClass.SHELL:
            if repr_id >= shells_len:
                raise ValueError(
                    f"Representation {i} points to shell {repr_id}, but shells length is {shells_len}"
                )
        elif repr_class == FBRepresentationClass.RepresentationClass.CIRCLE_EXTRUSION:
            if repr_id >= circle_extrusions_len:
                raise ValueError(
                    "Representation points to missing circle extrusion "
                    f"(id={repr_id}, count={circle_extrusions_len})"
                )
        else:
            raise ValueError(f"Unsupported representation class {repr_class} at index {i}")

    for i in range(shells_len):
        shell = meshes.Shells(i)
        if shell is None:
            raise ValueError(f"Null shell at index {i}")
        point_count = shell.PointsLength()
        if point_count < 3:
            raise ValueError(f"Shell {i} has too few points: {point_count}")
        shell_type = shell.Type()
        profile_count = shell.ProfilesLength()
        big_profile_count = shell.BigProfilesLength()
        if shell_type == FBShellType.ShellType.BIG:
            if big_profile_count == 0:
                raise ValueError(f"Shell {i} type BIG has no big profiles")
        else:
            if profile_count == 0:
                raise ValueError(f"Shell {i} type NONE has no profiles")

    for i in range(samples_len):
        sample = meshes.Samples(i)
        if sample is None:
            raise ValueError(f"Null sample at index {i}")
        item_idx = sample.Item()
        material_idx = sample.Material()
        representation_idx = sample.Representation()
        local_transform_idx = sample.LocalTransform()

        if item_idx >= meshes_items_len:
            raise ValueError(
                f"Sample {i} item index out of range: {item_idx} >= {meshes_items_len}"
            )
        if material_idx >= materials_len:
            raise ValueError(
                f"Sample {i} material index out of range: {material_idx} >= {materials_len}"
            )
        if representation_idx >= representations_len:
            raise ValueError(
                "Sample {i} representation index out of range: "
                f"{representation_idx} >= {representations_len}"
            )
        if local_transform_idx >= local_transforms_len:
            raise ValueError(
                f"Sample {i} local transform index out of range: "
                f"{local_transform_idx} >= {local_transforms_len}"
            )

    for i in range(meshes_items_len):
        local_id_array_index = meshes.MeshesItems(i)
        if local_id_array_index >= local_ids_len:
            raise ValueError(
                "meshes_items index references invalid local_ids index: "
                f"{local_id_array_index} >= {local_ids_len}"
            )

    return FragSummary(
        file=str(path),
        compressed_input=compressed_input,
        local_ids=local_ids_len,
        categories=categories_len,
        guids=guids_len,
        meshes_items=meshes_items_len,
        global_transforms=global_transforms_len,
        local_transforms=local_transforms_len,
        materials=materials_len,
        representations=representations_len,
        shells=shells_len,
        circle_extrusions=circle_extrusions_len,
        samples=samples_len,
        max_local_id=model.MaxLocalId(),
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate That Open .frag files.")
    parser.add_argument("frag_files", nargs="+", help=".frag files to validate")
    parser.add_argument("--json", action="store_true", help="Print summary as JSON")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    failures = 0
    summaries: List[FragSummary] = []

    for frag_file in args.frag_files:
        path = Path(frag_file).expanduser().resolve()
        if not path.exists():
            failures += 1
            print(f"FAILED: {path} (file does not exist)", file=sys.stderr)
            continue
        try:
            summary = validate_frag(path)
            summaries.append(summary)
            if not args.json:
                print(
                    f"VALID: {path.name} | "
                    f"items={summary.meshes_items} reps={summary.representations} "
                    f"shells={summary.shells} mats={summary.materials} samples={summary.samples} "
                    f"input={'compressed' if summary.compressed_input else 'raw'}"
                )
        except Exception as exc:
            failures += 1
            print(f"FAILED: {path} -> {exc}", file=sys.stderr)

    if args.json:
        payload: Dict[str, object] = {
            "valid_files": len(summaries),
            "failed_files": failures,
            "files": [asdict(summary) for summary in summaries],
        }
        print(json.dumps(payload, indent=2))

    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
